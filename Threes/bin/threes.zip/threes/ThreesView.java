package threes;

import java.awt.Font;

public interface ThreesView 
{
	Font font = new Font("Arial", 0, 22);
	
	public void update();
}
